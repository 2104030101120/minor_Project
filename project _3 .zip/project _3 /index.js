document.getElementById('side_cart');
var display=0;



function cartshow(){
if(display==1){
    div.style.display="block"
    display=0;
}
 else{
    div.style.display="block"
    display=1;
 }
}